/* arrayify.c
 *   produce armfpe.h for use with armulator
 */

/*
 * Copyright (C) Advanced RISC Machines Limited, 1992-7 (now named ARM Limited).
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of Advanced RISC Machines Limited nor ARM Limited nor
 *       the names of its contributors may be used to endorse or promote
 *       products derived from this software without specific prior written
 *       permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdio.h>
#include "aif.h"

static unsigned32 getword(in)
FILE *in;
{ unsigned32 i = fgetc(in);
  if (i == EOF) return 0xffffffff;
  i += fgetc(in) * 0x100l;
  i += fgetc(in) * 0x10000l;
  i += fgetc(in) * 0x1000000l;
  return i;
}

#define hdr_words (sizeof(struct aif_hdr) / sizeof(unsigned32))

int main(argc,argv)
int argc;
char *argv[];
{ FILE *in, *out;
  unsigned long i, j;
  unsigned long aif_words;
  union {
    struct aif_hdr h;
    unsigned32 w[hdr_words];
   } hdr;

  if (argc != 3)
    fprintf(stderr, "Syntax: %s <input file name> <output filename>\n", argv[0]);

  if ((in = fopen(argv[1], "r")) == NULL) {
    fprintf(stderr, "Input file error\n");
    perror(argv[0]);
    return 1;
    }
  if ((out = fopen(argv[2], "w")) == NULL) {
    fprintf(stderr, "Output file error\n");
    perror(argv[0]);
    return 1;
    }

  fprintf(out,"\
/*\n\
 * RCS $Revision: 1.4 $\n\
 * Checkin $Date: 1995/05/25 08:28:15 $\n\
 * Revising $Author: irickard $\n\
 */\n\n\
");

  fprintf(out,"#include \"aif.h\"\n\n");
  for (j = 0; j < hdr_words; j++)
    hdr.w[j] = getword(in);
  aif_words = (hdr.h.rosize + hdr.h.rwsize) / sizeof(unsigned32);

  fprintf(out,"static struct {\n struct aif_hdr hdr;\n unsigned32 code[%ld];\n} fpe = {\n  {", aif_words+1);

  for (j = 0; j < hdr_words; j++) {
    fprintf(out, "%s0x%.8lx,", ((j % 4) == 0) ? "\n" : "", hdr.w[j]);
  }
  fputs("\n  },\n  {", out);

  for (j = 0; j < aif_words; j++) {
    i = getword(in);
    fprintf(out,"%s0x%.8lx,", ((j % 4) == 0) ? "\n" : "", i);
  }

  fputs("0\n  }\n};\n", out);
  fclose(in);
  fclose(out);
  return(0);
}
